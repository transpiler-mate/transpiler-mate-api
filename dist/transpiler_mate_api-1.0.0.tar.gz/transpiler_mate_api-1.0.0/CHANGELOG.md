# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

### Changed

### Deprecated

### Removed

### Fixed

### Security

## [0.1.0] - 2026-09-01

### Added

- Initial release.

[unreleased]: https://github.com/Terradue/transpiler-mate-api/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/Terradue/state-mate/releases/tag/v0.1.0
